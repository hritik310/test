from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from .manager import CustomUserManager
from django_countries.fields import CountryField
from phone_field import PhoneField
# from multiselectfield import MultiSelectField
# Create your models here.
class User(AbstractBaseUser,PermissionsMixin):
	id = models.AutoField(primary_key=True)
	USER_TYPE_CHOICES = (
        ("superadmin", 0),
        ("admin", 1), 
        ("user", 2), 
    )
	user_type 	= models.IntegerField(choices = USER_TYPE_CHOICES,default="2")
	username 	= models.CharField(_('username'),max_length=255,default="")
	name 		= models.CharField(_('name'),max_length=255,default="")
	owner		= models.CharField(_('owner'),max_length=255,default="")
	tax_id		= models.IntegerField(null=True)
	email 		= models.EmailField(_('email'),unique=True)
	is_staff 	= models.BooleanField(default=False, help_text='Designates whether the user can log into this admin site.')
	is_active 	= models.BooleanField(default=True,
		help_text='Designates whether this user should be treated as active.\
		Unselect this instead of deleting accounts.')

	#date_joined = models.DateTimeField(_('date joined'), default=timezone.now)

	USERNAME_FIELD 	='email'
	objects 		= CustomUserManager()

	def __str__(self):
		return self.email
# Create your models here.


class Customer(models.Model):
	passport_id	= models.PositiveIntegerField(default=1)
	name 		= models.CharField(max_length=255,default="")
	country 	= CountryField(blank_label='select country',default="")
	phone 		= PhoneField(blank=True, help_text='Contact phone number',default="")
	address		= models.CharField(max_length=255,default="")


class Agencies(models.Model):
	INACTIVE = 0
	ACTIVE = 1
	STATUS = (
        (INACTIVE, _('Inactive')),
        (ACTIVE, _('Active')),
    )
	name 	= models.CharField(max_length=255,default="")
	domain 	= models.CharField(max_length=255,default="")
	active  = models.IntegerField(default=0, choices=STATUS)
	patente = models.CharField(max_length=255,default="")

class Pedimentos(models.Model):
	refrence_id 	= models.IntegerField(max_length=11,default="")
	pedimento_no 	= models.IntegerField()
	date  			= models.DateField()
	importer 		= models.CharField(max_length=255,default="")
	office 			= models.CharField(max_length=255,default="")
	signature 		= models.CharField(max_length=255,default="")
	payment 		= models.FloatField(max_length=255,default="")
	cove 			= models.CharField(max_length=255,default="")
	doda	 		= models.CharField(max_length=255,default="")
	ready 			= models.BooleanField()

class Inventory(models.Model):
	order_no 	= models.IntegerField(max_length=11,default="")
	quantity 	= models.IntegerField(max_length=11,default="")
	unit_type  	= models.IntegerField(max_length=11,default="")
	vechicle 	= models.CharField(max_length=255,default="")
	description = models.CharField(max_length=255,default="")
	price 		= models.FloatField(max_length=255,default="")
	price_total = models.FloatField(max_length=255,default="")


class Shipper_Exports(models.Model):
	INACTIVE = 0
	ACTIVE = 1
	STATUS = (
        (INACTIVE, _('Inactive')),
        (ACTIVE, _('Active')),
    )
	itn 		= models.CharField(max_length=11,default="")
	date  		= models.DateField()
	refrence 	= models.CharField(max_length=255,default="")
	name 		= models.CharField(max_length=255,default="")
	vin 		= models.CharField(max_length=255,default="")
	make 		= models.CharField(max_length=255,default="")
	year 		= models.IntegerField(max_length=255,default="")
	note	 	= models.CharField(max_length=255,default="")

class Insurance(models.Model):
		INACTIVE = 0
		ACTIVE = 1
		STATUS = (
		    (INACTIVE, _('Inactive')),
		    (ACTIVE, _('Active')),
		)
		date  	= models.DateField()
		ins_name 	= models.CharField(max_length=255,default="")
		days 	= models.IntegerField(max_length=255,default="")
		vin 	= models.CharField(max_length=255,default="")
		make 	= models.CharField(max_length=255,default="")
		year 	= models.IntegerField(max_length=255,default="")
		note	= models.CharField(max_length=255,default="")

class Temporary_Permits(models.Model):
		INACTIVE = 0
		ACTIVE = 1
		STATUS = (
		    (INACTIVE, _('Inactive')),
		    (ACTIVE, _('Active')),
		)
		permit_date  	= models.DateField()
		permit_name 	= models.CharField(max_length=255,default="")
		permit_hour 	= models.FloatField(max_length=255,default="")
		permit_number 	= models.CharField(max_length=255,default="")
		permit_vin 		= models.CharField(max_length=255,default="")
		permit_make 	= models.CharField(max_length=255,default="")
		permit_year 	= models.IntegerField(max_length=255,default="")
		permit_note		= models.CharField(max_length=255,default="")



	