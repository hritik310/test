from django.urls import path, re_path
from app import views

urlpatterns = [
    # Matches any html file - to be used for gentella
    # Avoid using your .html in your resources.
    # Or create a separate django app.
    re_path(r'^.*\.html', views.gentella_html, name='gentella'),

    # The home page
    path('', views.userLogin, name='login'),
    path('html', views.index, name='html'),
    path('home/', views.home, name='home'),
    path('login/',views.userLogin,name='login'),
    path('logout/',views.userLogout,name='logout'),


    # customer urls
    path('customer/',views.customer,name='customer'),
    path('customer/create',views.customerCreate,name='customerCreate'),
    path('customer/update/<int:id>/',views.customerupdate,name='customerupdate'),
    path('customer/delete/<int:id>',views.customerdelete, name ="customerdelete"), 


    # provider urls  
    path('provider/',views.provider,name='provider'),
    path('provider/index',views.providerIndex,name='providerIndex'),
    path('provider/update/<int:id>/',views.providerupdate,name='providerupdate'),
    path('provider/delete/<int:id>',views.providerdelete, name ="providerdelete"),

    # agencies urls
    path('agencies/',views.agencies,name='agencies'),
    path('agencies/create',views.agenciesCreate,name='agenciesCreate'),
    path('agencies/update/<int:id>/',views.agenciesupdate,name='agenciesupdate'),
    path('agencies/delete/<int:id>',views.agenciesdelete, name ="agenciesdelete"),

    # pedimentos urls
    path('pedimentos/',views.pedimentos,name='pedimentos'),
    path('pedimentos/create',views.pedimentosCreate,name='pedimentosCreate'),
    path('pedimentos/update/<int:id>/',views.pedimentos_update,name='pedimentos_update'),
    path('pedimentos/delete/<int:id>',views.pedimentos_delete, name ="pedimentos_delete"), 

    # inventory urls
    path('inventory/',views.inventory,name='inventory'),
    path('inventory/create',views.create_inventory,name='create_inventory'),
    path('inventory/update/<int:id>/',views.inventory_update,name='inventory_update'),
    path('inventory/delete/<int:id>',views.inventory_delete, name ="inventory_delete"), 

    # shipper urls
    path('shipper/',views.shipper, name='shipper'),
    path('shipper/create',views.create_shipper,name='shipper_create'),
    path('shipper/update/<int:id>/',views.shipper_update,name='shipper_update'),
    path('shipper/delete/<int:id>',views.shipper_delete, name ="shipper_delete"),

    # insurance urls
     path('insurance/',views.insurance,name='insurance'),
     path('insurance/create',views.insurance_create,name='insurance_create'),
     path('insurance/update/<int:id>/',views.insurance_update,name='insurance_update'),
     path('insurance/delete/<int:id>',views.insurance_delete, name ="insurance_delete"),

    #temporary permits urls
    path('temp_permits/',views.temp_permits,name='temp_permits'),
    path('temp_permits/create',views.create_temp_permits,name='create_temp_permits'),
    path('temp_permits/update/<int:id>/',views.temp_permitsupdate,name='temp_permits_update'),
    path('temp_permits/delete/<int:id>',views.temp_permitsdelete, name ="temp_permits_delete"),
   
]
